using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Reflection;
using System.Data.SqlClient;
using System.Data;



namespace LMS1.Pages
{
    public class IndexModel : PageModel
    {
        public DataSet Books{get; set;} 
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            string connectionString = "Data Source=(localdb)\\ProjectModels;Initial Catalog=LMS;Integrated Security=True;Trust Server Certificate=true;DATABASE=LMS";
            string sqlQuery = "select * from dbo.Books";
            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand sc = new SqlCommand(sqlQuery, con);
            SqlDataAdapter sda = new SqlDataAdapter(sc);

            Books = new DataSet();

            sda.Fill(Books);

            con.Close();
        }

    

        public void OnPost()
        {
            string ISBN = Request.Form["ISBN"]; 
            string Price = Request.Form["Price"];
            string Category = Request.Form["Category"];
            string Edition = Request.Form["Edition"];
            string Title = Request.Form["Title"];
            string connectionString = "Data Source=(localdb)\\ProjectModels;Initial Catalog=LMS;Integrated Security=True;Trust Server Certificate=true;DATABASE=LMS";
            string sqlQuery = "INSERT INTO dbo.Books (ISBN, Price,Category,Edition,Title) VALUES(" + "'" + ISBN + "'" + "," + "'" + Price + "'" + "," + "'" + Category + "'" + "," + "'" + Edition + "'" + ","+ "'" + Title + "'" + " )";


            SqlConnection con = new SqlConnection(connectionString);

            con.Open();
            SqlCommand sc = new SqlCommand(sqlQuery, con);
            sc.ExecuteNonQuery();
            con.Close();


        }

    }
}
